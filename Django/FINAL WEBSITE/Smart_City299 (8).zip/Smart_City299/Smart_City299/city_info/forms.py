from django.contrib.auth import get_user_model
from django import forms

from .models import spot_information


# from django.contrib.auth.models import User
class UserForm(forms.ModelForm):
        # this specifies that when inputing password that it should be hidden so others cannot view from behind backs etc.
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        # this allows a form to be automatically created according to fields
        User = get_user_model()
        model = User
        fields = ['username', 'email', 'address', 'phone_number', 'password']
        # 'address', 'phone',
        #  'address', 'phone_number',


class SpotinformationForm(forms.ModelForm):
    # this allows a form to be automatically created according to fields, this was a test, so does not work
    class Meta:
        model = spot_information
        fields = ['plname', 'location', 'start_rating', 'contact', 'streetname', 'streetnumber', 'description', 'image']

        # plname = models.CharField(max_length=300)
        # location = models.ForeignKey(location_detail, on_delete=models.CASCADE)
        # start_rating = models.IntegerField(default=1)
        # contact = models.IntegerField(default=0)
        # streetname = models.CharField(max_length=200)
        # streetnumber = models.IntegerField(default=0)
        # description = models.TextField(max_length=8000)
        # image = models.FileField()
        # afavourite = models.BooleanField(default=False)
