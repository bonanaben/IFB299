from django.db import models
from django.core.urlresolvers import reverse
from django.contrib.auth.models import AbstractUser

from datetime import datetime
from datetime import datetime
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from multiselectfield import MultiSelectField
from django.template.defaultfilters import slugify




# this is where the database begins

# extra user details
class User(AbstractUser):
    phone_number = models.IntegerField(default=0)
    address = models.CharField(max_length=150)
    # considered useless, was a test
    user_type = models.CharField(default="", max_length=120)


# location of where spots are, severl spots can be in one location
class location_detail(models.Model):
    location_name = models.CharField(max_length=300, help_text="*required")
    country = models.CharField(max_length=200)
    state = models.CharField(max_length=200)
    suburb = models.CharField(max_length=200)
    postcode = models.IntegerField(default=0)

    def __str__(self):
        return self.location_name + ", " + self.suburb + " (" + str(self.postcode) + ")"

    ''' this return statement should return everything, might have to change, except remove ID '''


# the very spotinformtaion itself
class spot_information(models.Model):
    # these are the filters of all spotinformations according to the categries below
    category_choices = (
        ('HOTELS', 'hotels'),
        ('COLLEGES', 'colleges'),
        ('LIBRARY', 'library'),
        ('INDUSTRY', 'industry'),
        ('ENTERTAINMENT', 'entertainment')
    )
    plname = models.CharField(max_length=300)
    location = models.ForeignKey(location_detail, on_delete=models.CASCADE)
    start_rating = models.IntegerField(default=1)
    contact = models.IntegerField(default=0)
    streetname = models.CharField(max_length=200)
    streetnumber = models.IntegerField(default=0)
    description = models.TextField(max_length=8000)
    category = models.CharField(default='', max_length=10, choices=category_choices)
    image = models.FileField()
    a_favourite = models.BooleanField(default=False)

    def get_absolute_url(self):
        return reverse('cityinfo:cityinfo_details', kwargs={'pk': self.pk})

    def __str__(self):
        return self.plname


# user when he/she saves a spot, requres user ID and the spotinformation
class user_favourite_spot(models.Model):
    spot_information = models.ForeignKey(spot_information)
    user = models.ForeignKey(User)

    def get_absolute_url(self):
        return reverse('cityinfo:user_favorites', kwargs={'pk': self.pk})


'''
    spot_information
    location_detail

    streetname = models.CharField(max_length=200)
    streetnumber = models.IntegerField(default=0)
'''


USER_TYPES = (
    ('Tourist', 'Tourist'),
    ('Student', 'Student'),
    ('Businessman', 'Businessman'),
)

USER_INTERESTS = (
    ('Colleges', 'Colleges'),
    ('Libraries', 'Libraries'),
    ('Industries', 'Industries'),
    ('Hotels', 'Hotels'),
    ('Parks', 'Parks'),
    ('Zoos', 'Zoos'),
    ('Museums', 'Museums'),
    ('Restaurants', 'Restaurants'),
    ('Malls', 'Malls'),
)


class Category(models.Model):
    """
    Model representing a location category (e.g. Colleges, Parks, Mueseums etc.).
    """
    name = models.CharField(max_length=200, help_text="Enter a location category (e.g. Colleges, Parks, Mueseums etc.)")

    class Meta:
        verbose_name_plural = 'Categories'

    def __str__(self):
        """
        String for representing the Model object (in Admin site etc.)
        """
        return self.name

class Country(models.Model):
    """
    Model representing a country.
    """
    name = models.CharField(max_length=255, help_text="Enter a country (e.g. Australia, New Zealand, China etc.)")
    code = models.CharField(max_length=10, help_text="Enter a country code (e.g. AUS, NZ, CHN etc.)")

    class Meta:
        verbose_name_plural = 'Countries'

    def __str__(self):
        """
        String for representing the Model object.
        """
        return '%s (%s)' % (self.name, self.code)

class Region(models.Model):
    """
    Model representing a region (regions/provinces/states).
    """
    name = models.CharField(max_length=255, help_text="Enter a region (region/province/state)")
    code = models.CharField(max_length=10, help_text="Enter a region code (e.g. QLD, NSW, VIC etc.)")
    country_id = models.ForeignKey(Country, on_delete=models.CASCADE)


    def __str__(self):
        """
        String for representing the Model object.
        """
        return '%s (%s)' % (self.name, self.code)

class City(models.Model):
    """
    Model representing a city.
    """
    name = models.CharField(max_length=255, help_text="Enter a city (e.g. Brisbane, Sydney, Perth etc.)")
    region_id = models.ForeignKey(Region, on_delete=models.CASCADE)
    country_id = models.ForeignKey(Country, on_delete=models.CASCADE)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)

    class Meta:
        verbose_name_plural = 'Cities'

    def __str__(self):
        """
        String for representing the Model object.
        """
        return self.name

class Location(models.Model):
    """
    Model representing a location
    """
    name = models.CharField(max_length=255)
    address = models.CharField(max_length=255, help_text="Enter the street address (e.g. 123 Evergreen Tce)")
    #description = models.TextField(max_length=1000, help_text="Enter a brief description of the location")
    ## Lat/Long
    latitude = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)
    ## Slug
    slug = models.SlugField()
    ## FK
    city_id = models.ForeignKey(City, on_delete=models.CASCADE)
    region_id = models.ForeignKey(Region, on_delete=models.CASCADE)
    country_id = models.ForeignKey(Country, on_delete=models.CASCADE)

    def save(self, *args, **kwargs):
        self.slug = slugify(self.name)
        super(Location, self).save(*args, **kwargs)

    def __str__(self):
        """
        String for representing the Model object.
        """
        return self.name

class Event(models.Model):
    """
    Model representing a event
    """
    name = models.CharField(max_length=255)
    description = models.TextField(max_length=1000, help_text="Enter a brief description of the event")
    start_date = models.DateTimeField(default=datetime.now, blank=True)
    end_date = models.DateTimeField(default=datetime.now, blank=True)
    ##FK
    location_id = models.ForeignKey(Location, on_delete=models.CASCADE)

    def __str__(self):
        """
        String for representing the Model object.
        """
        return self.name
