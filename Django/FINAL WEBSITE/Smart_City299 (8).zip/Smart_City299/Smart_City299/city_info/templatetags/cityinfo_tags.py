from django import template

from city_info.models import user_favourite_spot

register = template.Library()

@register.simple_tag
def marked_favourite(userId, spotId):
    try:
        favourite_spot = user_favourite_spot.objects.get(user_id=userId, spot_information_id=spotId)
        return 'active'
    except user_favourite_spot.DoesNotExist:
        return ''