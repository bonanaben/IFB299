from django.conf.urls import url
from . import views
from django.contrib.auth import views as auth_views

app_name = 'cityinfo'

urlpatterns = [
    # Home page /cityinfo
    url(r'^$', views.index, name="cityinfo_index"),

    # search
    url(r'^$', views.index_search, name="index_search"),
    
    # details page
    url(r'^(?P<spot_id>[0-9]+)/$', views.detail, name="cityinfo_details"),

    # users favourites page (?P<fav_id>[0-9]+)
    url('favorites/', views.user_favorites, name="user_favorites"),

    # Login
    url(r'^register/$', views.UserFormView.as_view(), name="register"),

    # filter spots
    url(r'^spots/(?P<filter_by>[a-zA_Z]+)/$', views.spots, name='spots'),

    # logging in
    url(r'^login_user/$', views.login_user, name="login_user"),

    # logging off
    url(r'^logout_user/$', views.logout_user, name="logout_user"),

    # favourite
    url('favorite', views.favorite, name='favorite'),

     url(r'^location/$', views.location, name='location'),

   ## Location page
   url(r'^location/(?P<location_name_slug>[\w\-]+)/$', views.location, name='location'),

]
