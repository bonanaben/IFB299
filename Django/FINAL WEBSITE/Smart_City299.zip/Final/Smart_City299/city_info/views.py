import operator
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.contrib.auth import authenticate, login
from django.contrib.auth import logout
from django.shortcuts import render, get_object_or_404, get_list_or_404
from django.core.urlresolvers import reverse_lazy
from django.shortcuts import render, redirect
from django.db.models import Q
from django.contrib.auth import authenticate, login
from django.contrib.auth.views import login
from django.http import HttpResponseRedirect, HttpResponse
from django.views.generic import View
from .models import spot_information, location_detail, User, user_favourite_spot
from .forms import UserForm, SpotinformationForm
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import json
from functools import reduce


# this is
# def myView(request):
#     if request.user.is_authenticated:
#         return render(request, 'cityinfo/cityinfo_index.html')
#     else:
#         return render(request, 'cityinfo/login.html')

# this is for favoriting spot information, this allows users to select and deselct (star button)
# related pages include main.js

# this is where favouriting happens, the user selects the star, and it saves according to user id into a table
# caller "user_favourite_spots" (in models)
# if the star is alredy selected and the user selects it, delete from the table, and the star is unselected
@csrf_exempt
def favorite(request):
    if request.is_ajax():
        if request.POST:
            try:
                favorite_spot = user_favourite_spot()
                favorite_spot.user = request.user
                data = json.loads(request.body)
                spotId = data['spotId']
                spotinformation = spot_information.objects.get(id=spotId)
                favorite_spot.spot_information = spotinformation
                try:
                    existingFavouriteSpot = user_favourite_spot.objects.get(user_id=request.user.id,
                                                                            spot_information_id=spotinformation.id)
                    existingFavouriteSpot.delete()
                except(user_favourite_spot.DoesNotExist):
                    favorite_spot.save()

                return JsonResponse({'success': True})
            except (KeyError, spot_information.DoesNotExist):
                return JsonResponse({'success': False})
            else:
                return JsonResponse({'success': True})
    else:
        return JsonResponse({'success': False, 'message': 'Bad Request'})


def welcome(request):
    return render(request, 'cityinfo/welcomePage.html')


# index search is where the user searches for the place name
# if user is not logged in it redirects, else it allows the user to search, the search (query/"q") is used
# and (case sensitive or not) the user will be displayed with the matching words closest to
# for example "qu" = Queen Street Mall (filtering according to query(users search))
def index_search(request):
    if not request.user.is_authenticated():
        return render(request, 'cityinfo/login.html')
    else:
        # this displays all spot_informations in the database
        spot_informations = spot_information.objects.all()
        query = request.GET.get("q")
        # unless the user searches for something then follows the if statement below
        if query:
            spot_informations = spot_informations.filter(
                Q(plname__icontains=query)
            ).distinct()
            result = spot_information.objects.filter(plname__icontains=query)
            return render(request, 'cityinfo/cityinfo_index.html', {
                'spot_informations': result,
            })
        else:
            return render(request, "cityinfo/cityinfo_index.html")


# begins by stating to follow the above function (index_search) if the user has searched
def index(request):
    if request.GET.get('q'):
        return index_search(request)
    # below checks if user is authenticated or not, else redirects to login page, to log back in
    if not request.user.is_authenticated():
        return render(request, 'cityinfo/login.html')
    else:
        # this is where filtering happens where the user filters when clicking student, business or tourist
        # according to category
        all_spot_information = []
        if request.GET.get('cat'):
            categoryQueryParam = request.GET.get('cat')
            if "|" in categoryQueryParam:
                categories = categoryQueryParam.split('|')
                all_spot_information = spot_information.objects.filter(
                    reduce(lambda x, y: x | y, [Q(category__iexact=cat) for cat in categories]))
            else:
                all_spot_information = spot_information.objects.filter(category__iexact=categoryQueryParam)
        else:
            all_spot_information = spot_information.objects.all()
        context = {
            "all_spot_information": all_spot_information
        }
        return render(request, 'cityinfo/cityinfo_index.html', context)


# # this is scrap
# def index_searchM(request):
#     if not request.user.is_authenticated():
#         return render(request, 'cityinfo/login.html')
#     else:
#         spot_informations = spot_information.objects.get(pk=request.user.pk)
#         query = request.GET.get("q")
#         if query:
#             spot_informations = spot_informations.filter(
#                 Q(plname__icontains=query) |
#                 Q(location__icontains=query) |
#                 Q(streetname__icontains=query)
#             ).distinct()
#             return render(request, 'cityinfo/cityinfo_index.html', {
#                 'spot_informations': spot_informations,
#             })
#         else:
#             return render(request, 'cityinfo/cityinfo_index.html', {'spot_informations': spot_informations})

# this is the deatils page where viewing more details about the selected spot in index page
def detail(request, spot_id):
    if not request.user.is_authenticated():
        return render(request, 'cityinfo/login.html')
    else:
        spotinformation = get_object_or_404(spot_information, id=spot_id)
        context = {
            "spotinformation": spotinformation
        }
        return render(request, 'cityinfo/cityinfo_details.html', context)


# def AuthRequiredMiddleware(object):
#     def process_request(self, request):
#         if not request.user.is_authenticated():
#             return HttpResponseRedirect('login.html')  # or http response
#         return None

# this is where the user is able to view all his/her faourites
def user_favorites(request):
    # if not logged in, redirect to login page
    if not request.user.is_authenticated():
        return render(request, 'cityinfo/login.html')
    else:
        favorites = get_list_or_404(user_favourite_spot, user_id=request.user.id)
        # get all spot information
        all_spot_information = []
        # then filter through by favourited spotinformations to display
        for favorite in favorites:
            all_spot_information.append(favorite.spot_information)
        context = {
            "all_spot_information": all_spot_information
        }
        return render(request, 'cityinfo/user_favorites.html', context)


def logout_user(request):
    logout(request)
    form = UserForm(request.POST or None)
    context = {
        "form": form,
    }
    return render(request, 'cityinfo/login.html', context)


# users login
def login_user(request):
    # requesting username and password
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        # validate
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                # if user is valid login the user requesting information to be displayed (pk=request.user.pk) {'spot_informations': spot_informations}
                login(request, user)
                spot_informations = spot_information.objects.all()
                return render(request, 'cityinfo/cityinfo_index.html', {'spot_informations': spot_informations})
            else:
                return render(request, 'cityinfo/login.html', {'error_message': 'Your account has been disabled'})
        else:
            return render(request, 'cityinfo/login.html', {'error_message': 'Invalid login'})

    return render(request, 'cityinfo/login.html')  # adding a new location


# scrap
# class NewLocation(CreateView):
#     model = location_detail
#     fields = ['location_name', 'country', 'state', 'suburb', 'postcode']

#
class UserFormView(View):
    form_class = UserForm
    template_name = 'cityinfo/registration_form.html'

    # blank form (new user)
    def get(self, request):
        form = self.form_class(None)
        return render(request, self.template_name, {'form': form})

    # processing form data
    def post(self, request):
        form = self.form_class(request.POST)

        if form.is_valid():

            user = form.save(commit=False)

            # cleaned (normalizes) data
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user.set_password(password)
            user.save()

            # returns user objects if credentials are correct
            user = authenticate(username=username, password=password)

            if user is not None:

                if user.is_active:
                    login(request, user)
                    return redirect('cityinfo:cityinfo_index')

            return render(request, self.template_name, {'form': form})


# not being used, was a test
def spots(request, filter_by):
    if not request.user.is_authenticated():
        return render(request, 'cityinfo/login.html')
    else:
        try:
            spot_ids = []
            for spots in spot_information.objects.filter(user=request.user):
                for spot in spots.spot_set.all():
                    spot_ids.append(spot.pk)
            users_spots = spot_information.objects.filter(pk__in=spot_ids)
            if filter_by == 'favorites':
                users_spots = users_spots.filter(afavorite=True)
        except spot_information.DoesNotExist:
            users_spots = []
        return render(request, 'cityinfo/cityinfo_index.html', {
            'spot_list': users_spots,
            'filter_by': filter_by,
        })


# KIRANS PART BELOW
def get_place_id(location_name):
    url = "https://maps.googleapis.com/maps/api/place/textsearch/json?key=AIzaSyBvXpcHlbpL_ESnnNOm07nBCd1LhpZOSzw&location=-27.470125,153.021072&radius=20&query=" + location_name
    response = requests.get(url)
    file = response.json()

    place_id = file['results'][0]['place_id']
    # print(place_id)

    return place_id


# @login_required
def location(request, location_name_slug):
    context_dict = {}
    # Get the place_id based on the name of the location
    place_id = get_place_id(location_name_slug)

    # Search for the location using the place_id
    url = "https://maps.googleapis.com/maps/api/place/details/json?placeid=" + place_id + "&key=AIzaSyBvXpcHlbpL_ESnnNOm07nBCd1LhpZOSzw"

    response = requests.get(url)
    file = response.json()

    # print(file)

    context_dict['name'] = file['result']['name']
    context_dict['place_id'] = file['result']['place_id']

    try:
        context_dict['formatted_address'] = file['result']['formatted_address']
    except KeyError:
        pass
    try:
        context_dict['formatted_phone_number'] = file['result']['formatted_phone_number']
    except KeyError:
        pass
    try:
        context_dict['rating'] = file['result']['rating']
    except KeyError:
        pass
    try:
        context_dict['website'] = file['result']['website']
    except KeyError:
        pass
    try:
        context_dict['price_level'] = file['result']['price_level']
    except KeyError:
        pass
    try:
        context_dict['Monday'] = file['result']['opening_hours']['weekday_text'][0]
        context_dict['Tuesday'] = file['result']['opening_hours']['weekday_text'][1]
        context_dict['Wednesday'] = file['result']['opening_hours']['weekday_text'][2]
        context_dict['Thursday'] = file['result']['opening_hours']['weekday_text'][3]
        context_dict['Friday'] = file['result']['opening_hours']['weekday_text'][4]
        context_dict['Saturday'] = file['result']['opening_hours']['weekday_text'][5]
        context_dict['Sunday'] = file['result']['opening_hours']['weekday_text'][6]
    except KeyError:
        pass
    try:
        context_dict[
            'Photo'] = 'https://maps.googleapis.com/maps/api/place/photo?maxwidth=500&maxheight=500&key=AIzaSyBvXpcHlbpL_ESnnNOm07nBCd1LhpZOSzw&photoreference=' + \
                       file['result']['photos'][0]['photo_reference']
        context_dict[
            'Photo2'] = 'https://maps.googleapis.com/maps/api/place/photo?maxwidth=500&key=AIzaSyBvXpcHlbpL_ESnnNOm07nBCd1LhpZOSzw&photoreference=' + \
                        file['result']['photos'][1]['photo_reference']
        context_dict[
            'Photo3'] = 'https://maps.googleapis.com/maps/api/place/photo?maxwidth=500&key=AIzaSyBvXpcHlbpL_ESnnNOm07nBCd1LhpZOSzw&photoreference=' + \
                        file['result']['photos'][2]['photo_reference']
        context_dict[
            'Photo4'] = 'https://maps.googleapis.com/maps/api/place/photo?maxwidth=500&key=AIzaSyBvXpcHlbpL_ESnnNOm07nBCd1LhpZOSzw&photoreference=' + \
                        file['result']['photos'][3]['photo_reference']
        context_dict[
            'Photo5'] = 'https://maps.googleapis.com/maps/api/place/photo?maxwidth=500&key=AIzaSyBvXpcHlbpL_ESnnNOm07nBCd1LhpZOSzw&photoreference=' + \
                        file['result']['photos'][4]['photo_reference']
    except KeyError:
        pass
    try:
        context_dict['lat'] = file['result']['geometry']['location']['lat']
        context_dict['lng'] = file['result']['geometry']['location']['lng']
    except KeyError:
        pass
    return render(request, 'cityinfo/location.html', context_dict)
