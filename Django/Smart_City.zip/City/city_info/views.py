from django.views import generic
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from .models import spot_information

class IndexView(generic.ListView):
    template_name = 'cityinfo/cityinfo_index.html'

    def get_queryset(self):
        return spot_information.objects.all()
    # when this is done ^^^^ above then the default variable name it saves to is called "object_list"
    # refer to index.html
    # this however can be changed by doing this
    # context_object_name = 'whatever_Name_You_Want'
    context_object_name = 'all_spot_information'