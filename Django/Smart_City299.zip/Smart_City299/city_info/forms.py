from django.contrib.auth import get_user_model
from django import forms


# from django.contrib.auth.models import User
class UserForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        User = get_user_model()
        model = User
        fields = ['username', 'email', 'address', 'phone_number', 'password']
        # 'address', 'phone',
        #  'address', 'phone_number',
