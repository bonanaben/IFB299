from django.db import models
from django.core.urlresolvers import reverse
from django.contrib.auth.models import AbstractUser


# Create your models here.

class User(AbstractUser):
    phone_number = models.IntegerField(default=0)
    address = models.CharField(max_length=150)
    user_type = models.CharField(default="", max_length=120)


class location_detail(models.Model):
    location_name = models.CharField(max_length=300, help_text="*if required")
    country = models.CharField(max_length=200)
    state = models.CharField(max_length=200)
    suburb = models.CharField(max_length=200)
    postcode = models.IntegerField(default=0)

    def __str__(self):
        return self.location_name + ", " + self.suburb + " (" + str(self.postcode) + ")"

    ''' this return statement should return everything, might have to change, except remove ID '''


class spot_information(models.Model):
    plname = models.CharField(max_length=300)
    location = models.ForeignKey(location_detail, on_delete=models.CASCADE)
    start_rating = models.IntegerField(default=1)
    contact = models.IntegerField(default=0)
    streetname = models.CharField(max_length=200)
    streetnumber = models.IntegerField(default=0)
    description = models.TextField(max_length=8000)
    image = models.FileField()

    def get_absolute_url(self):
        return reverse('cityinfo:cityinfo_details', kwargs={'pk': self.pk})

    def __str__(self):
        return self.plname


'''
    spot_information
    location_detail

    streetname = models.CharField(max_length=200)
    streetnumber = models.IntegerField(default=0)
'''
