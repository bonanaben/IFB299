from django.conf.urls import url
from . import views
from django.contrib.auth import views as auth_views

app_name = 'cityinfo'

urlpatterns = [
    # Home page /cityinfo
    url(r'^$', views.index, name="cityinfo_index"),

    # search
    url(r'^$', views.index_search, name="index_search"),

    # favourites
    # url(r'^$', views.index_search, name="cityinfo_index"),

    # details page
    url(r'^(?P<spot_id>[0-9]+)/$', views.detail, name="cityinfo_details"),

    # checking if user is logged in else redirect to login page
    # url(r'^login/$', views.custom_login),

    # Login
    url(r'^register/$', views.UserFormView.as_view(), name="register"),

    # filter spots
    url(r'^spots/(?P<filter_by>[a-zA_Z]+)/$', views.spots, name='spots'),

    # logging in
    url(r'^login_user/$', views.login_user, name="login_user"),

    # logging off
    url(r'^logout_user/$', views.logout_user, name="logout_user"),

    # favourite
    url(r'^(?P<spot_id>[0-9]+)/favorite/$', views.favorite, name='favorite'),
]
