from django.contrib import admin
from .models import user_detail, location_detail, spot_information

# Register your models here.
admin.site.register(user_detail)
admin.site.register(location_detail)
admin.site.register(spot_information)

"""
u = admin 
p = william
"""

