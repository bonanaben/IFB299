from django.apps import AppConfig


class CityInfoConfig(AppConfig):
    name = 'city_info'
