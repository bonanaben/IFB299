from django.conf.urls import url
from . import views

app_name = 'cityinfo'

urlpatterns = [
        # Home page /cityinfo
    url(r'^$', views.index, name="cityinfo_index"),
        #details page
    url(r'^(?P<spot_id>[0-9]+)/$', views.detail, name="cityinfo_details")
]

