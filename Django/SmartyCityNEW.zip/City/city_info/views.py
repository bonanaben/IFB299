from .models import spot_information
from django.shortcuts import render, get_object_or_404, get_list_or_404
from django.core.urlresolvers import reverse_lazy
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.views.generic import View
from .forms import UserForm

def index(request):
    all_spot_information = spot_information.objects.all()
    context = {
        "all_spot_information": all_spot_information,
    }
    return render(request, 'cityinfo/cityinfo_index.html', context)

def detail(request, spot_id):
    spotinformation = get_object_or_404(spot_information, id=spot_id)
    context = {
        "spotinformation": spotinformation
    }
    return render(request, 'cityinfo/cityinfo_details.html', context)

class UserFormView(View):
    form_class = UserForm
    template_name = 'cityinfo/registration_form.html'

    # blank form (new user)
    def get(self, request):
        form = self.form_class(None)
        return render(request, self.template_name, {'form': form})

    # processing form data
    def post(self, request):
        form = self.form_class(request.POST)

        if form.is_valid():

            user = form.save(commit=False)

            # cleaned (normalizes) data
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user.set_password(password)
            user.save()

            # returns user objects if credentials are correct
            user = authenticate(username=username, password=password)

            if user is not None:

                if user.is_active:
                    login(request, user)
                    return redirect('cityinfo:cityinfo_index')

        return render(request, self.template_name, {'form': form})
