from .models import spot_information
from django.shortcuts import render, get_object_or_404, get_list_or_404

def index(request):
    all_spot_information = spot_information.objects.all()
    context = {
        "all_spot_information": all_spot_information,
    }
    return render(request, 'cityinfo/cityinfo_index.html', context)

def detail(request, spot_id):
    spotinformation = get_object_or_404(spot_information, id=spot_id)
    context = {
        "spotinformation": spotinformation
    }
    return render(request, 'cityinfo/cityinfo_details.html', context)