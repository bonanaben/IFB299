from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.contrib.auth import authenticate, login
from django.contrib.auth import logout
from django.shortcuts import render, get_object_or_404, get_list_or_404
from django.core.urlresolvers import reverse_lazy
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.views import login
from django.http import HttpResponseRedirect
from django.views.generic import View
from .models import spot_information, location_detail
from .forms import UserForm


def myView(request):
    if request.user.is_authenticated:
        return render(request, 'cityinfo_index.html')
    else:
        return render(request, 'login.html')


def index(request):
    if not request.user.is_authenticated():
        return render(request, 'cityinfo/login.html')
    else:
        all_spot_information = spot_information.objects.all()
        context = {
            "all_spot_information": all_spot_information,
        }
        return render(request, 'cityinfo/cityinfo_index.html', context)


def detail(request, spot_id):
    if not request.user.is_authenticated():
        return render(request, 'cityinfo/login.html')
    else:
        spotinformation = get_object_or_404(spot_information, id=spot_id)
        context = {
            "spotinformation": spotinformation
        }
        return render(request, 'cityinfo/cityinfo_details.html', context)


# def AuthRequiredMiddleware(object):
#     def process_request(self, request):
#         if not request.user.is_authenticated():
#             return HttpResponseRedirect('login.html')  # or http response
#         return None


def logout_user(request):
    logout(request)
    form = UserForm(request.POST or None)
    context = {
        "form": form,
    }
    return render(request, 'cityinfo/login.html', context)


def login_user(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                # spot_informations = spot_information.objects.filter(user=request.user)
                return render(request, 'cityinfo/cityinfo_index.html', {'spot_information': spot_information})
            else:
                return render(request, 'cityinfo/login.html', {'error_message': 'Your account has been disabled'})
        else:
            return render(request, 'cityinfo/login.html', {'error_message': 'Invalid login'})

    return render(request, 'cityinfo/login.html')  # adding a new location


# class NewLocation(CreateView):
#     model = location_detail
#     fields = ['location_name', 'country', 'state', 'suburb', 'postcode']

class UserFormView(View):
    form_class = UserForm
    template_name = 'cityinfo/registration_form.html'

    # blank form (new user)
    def get(self, request):
        form = self.form_class(None)
        return render(request, self.template_name, {'form': form})

    # processing form data
    def post(self, request):
        form = self.form_class(request.POST)

        if form.is_valid():

            user = form.save(commit=False)

            # cleaned (normalizes) data
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user.set_password(password)
            user.save()

            # returns user objects if credentials are correct
            user = authenticate(username=username, password=password)

            if user is not None:

                if user.is_active:
                    login(request, user)
                    return redirect('cityinfo:cityinfo_index')

            return render(request, self.template_name, {'form': form})
