from django.db import models

# Create your models here.
class user_detail(models.Model):
    user_id = models.AutoField(primary_key = True)
    fname = models.CharField(max_length=250)
    lname = models.CharField(max_length=250)
    email = models.CharField(max_length=100)

    def __str__(self):
        return self.fname + " " + self.lname

class location_detail(models.Model):
    location_id = models.AutoField(primary_key = True)
    location_name = models.CharField(max_length=300, default="location_name")
    country = models.CharField(max_length=200)
    state = models.CharField(max_length=200)
    suburb = models.CharField(max_length=200)
    streetname = models.CharField(max_length=200)
    streetnumber = models.IntegerField(default=0)
    postcode = models.IntegerField(default=0)

    def __str__(self):
        return "( ID: " + str(self.location_id) + " ) " + self.location_name
    ''' this return statement should return everything, might have to change, except remove ID '''

class spot_information(models.Model):
    city_id = models.AutoField(primary_key = True)
    plname = models.CharField(max_length=300)
    location = models.ForeignKey(location_detail, on_delete=models.CASCADE)
    start_rating = models.IntegerField(default=1)
    contact = models.IntegerField(default=0)
    description = models.TextField(max_length=8000)
    image = models.CharField(max_length=1000) 
    ''' images will be urls '''

    def __str__(self):
        return self.plname