from django.conf.urls import url
from . import views

app_name = 'cityinfo'

urlpatterns = [
        # Home page /cityinfo
    url(r'^$', views.IndexView.as_view(), name="cityinfo_index"),
]

