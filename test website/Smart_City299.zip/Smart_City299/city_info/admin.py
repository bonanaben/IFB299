from django.contrib import admin
from .models import User, location_detail, spot_information

# Register your models here.

# how the user edits within the database by logging in as admin and is able to edit the database using django
admin.site.register(User)
admin.site.register(location_detail)
admin.site.register(spot_information)