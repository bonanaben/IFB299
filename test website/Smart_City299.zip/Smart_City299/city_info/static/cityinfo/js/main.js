var SpotListPage = {
    init: function () {
        this.render();
        this.bindEvents();
    },

    render: function () {

    },

    bindEvents: function () {
        $('.favourite-btn').on('click', function (e) {
            e.preventDefault();

            var self = $(this);
            var spotId = $(this).data('spotid');

            $.post( "/cityinfo/favorite", JSON.stringify({spotId: spotId}))
                 .done(function( data ) {
                     $('.glyphicon-star', self).toggleClass('active');
              });

            return false;
        });
    }
};

$(document).ready(function () {
    SpotListPage.init();
});